"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import {
  ArrowLeft,
  CalendarDays,
  Check,
  FolderOpen,
  GraduationCap,
  Images,
  School,
  Plus,
  Settings,
  Shield,
  Users,
  X,
  Search,
  Pencil,
  Lock,
} from "lucide-react";
import { createClient } from "@/lib/supabase/client";

type ProjectRow = {
  id: string;
  project_name?: string | null;
  name?: string | null;
  title?: string | null;
  project_type?: string | null;
  type?: string | null;
  workflow_type?: string | null;
  workflow?: string | null;
  description?: string | null;
  status?: string | null;
  shoot_date?: string | null;
  portal_status?: string | null;
  school_id?: string | null;
  linked_school_id?: string | null;
  linked_local_school_id?: string | null;
  event_date?: string | null;
  client_name?: string | null;
  source_type?: string | null;
  cover_photo_url?: string | null;
  access_mode?: string | null;
  access_pin?: string | null;
};

type SchoolRow = {
  id: string;
  school_name: string;
  local_school_id: string | null;
  package_profile_id?: string | null;
};

type StudentRow = {
  id: string;
  class_name: string | null;
  role: string | null;
};

type CollectionRow = {
  id: string;
  title?: string | null;
  kind?: string | null;
  slug?: string | null;
  cover_photo_url?: string | null;
  sort_order?: number | null;
  created_at?: string | null;
  access_mode?: string | null;
  access_pin?: string | null;
};

type MediaRow = {
  id: string;
  collection_id?: string | null;
  preview_url?: string | null;
  thumbnail_url?: string | null;
  filename?: string | null;
  created_at?: string | null;
  sort_order?: number | null;
};

function clean(value: string | null | undefined) {
  return (value ?? "").trim();
}

function normalizedAccessMode(value: string | null | undefined) {
  const raw = clean(value).toLowerCase();
  if (!raw) return "public";
  if (raw === "pin" || raw === "protected" || raw === "private") return "pin";
  if (raw === "inherit" || raw === "inherit_project" || raw === "project") return "inherit_project";
  return raw;
}

function hasPinProtection(mode: string | null | undefined, pin: string | null | undefined) {
  return normalizedAccessMode(mode) === "pin" && clean(pin).length > 0;
}

function normalizeRole(rawRole: string | null | undefined): string {
  const role = clean(rawRole).toLowerCase();
  if (!role) return "Unassigned";
  if (role === "student" || role === "students") return "Student";
  if (role === "teacher" || role === "teachers") return "Teacher";
  if (role === "coach" || role === "coaches") return "Coach";
  if (["principal", "head principal", "school principal"].includes(role)) return "Principal";
  if (["office", "office staff", "admin", "administrator", "administration", "front office"].includes(role)) return "Office Staff";
  if (["staff", "faculty", "employee", "employees", "support staff", "school staff"].includes(role)) return "Staff";
  return clean(rawRole) || "Unassigned";
}

function formatDisplayDate(value: string | null | undefined) {
  if (!value) return "No date set";
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return "No date set";
  return d.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

function projectNameOf(project: ProjectRow | null) {
  return project?.project_name || project?.name || project?.title || "Untitled Project";
}

function mediaUrl(row: Pick<MediaRow, "preview_url" | "thumbnail_url"> | null | undefined) {
  return clean(row?.preview_url) || clean(row?.thumbnail_url) || "";
}

function sortCollections(rows: CollectionRow[]) {
  return [...rows].sort((a, b) => {
    const sortDelta = Number(a.sort_order ?? Number.MAX_SAFE_INTEGER) - Number(b.sort_order ?? Number.MAX_SAFE_INTEGER);
    if (sortDelta !== 0) return sortDelta;
    return clean(a.title).localeCompare(clean(b.title), undefined, { numeric: true, sensitivity: "base" });
  });
}

export default function ProjectDetailPage() {
  const supabase = useMemo(() => createClient(), []);
  const params = useParams();
  const projectId = String(params.id ?? "");

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [project, setProject] = useState<ProjectRow | null>(null);
  const [linkedSchool, setLinkedSchool] = useState<SchoolRow | null>(null);
  const [collections, setCollections] = useState<CollectionRow[]>([]);
  const [media, setMedia] = useState<MediaRow[]>([]);
  const [mediaCount, setMediaCount] = useState(0);

  const [classesCount, setClassesCount] = useState(0);
  const [rolesCount, setRolesCount] = useState(0);
  const [peopleCount, setPeopleCount] = useState(0);
  const [galleriesCount, setGalleriesCount] = useState(0);
  const [albumsCount, setAlbumsCount] = useState(0);

  const [menuAlbumId, setMenuAlbumId] = useState<string | null>(null);
  const [selectedAlbumId, setSelectedAlbumId] = useState<string | null>(null);
  const [selectedAlbumIds, setSelectedAlbumIds] = useState<string[]>([]);
  const [coverPickerOpen, setCoverPickerOpen] = useState(false);
  const [coverPickerTitle, setCoverPickerTitle] = useState("Choose Cover");
  const [coverTarget, setCoverTarget] = useState<{ type: "project" | "album"; albumId?: string } | null>(null);
  const [selectedMediaId, setSelectedMediaId] = useState<string | null>(null);
  const [savingCover, setSavingCover] = useState(false);
  const [newAlbumOpen, setNewAlbumOpen] = useState(false);
  const [newAlbumTitle, setNewAlbumTitle] = useState("");
  const [creatingAlbum, setCreatingAlbum] = useState(false);
  const [shareNotice, setShareNotice] = useState("");
  const [albumSearch, setAlbumSearch] = useState("");
  const [renameAlbumId, setRenameAlbumId] = useState<string | null>(null);
  const [renameAlbumTitle, setRenameAlbumTitle] = useState("");
  const [renamingAlbum, setRenamingAlbum] = useState(false);
  const [deleteAlbumId, setDeleteAlbumId] = useState<string | null>(null);
  const [deleteAlbumTitle, setDeleteAlbumTitle] = useState("");
  const [deleteAlbumIds, setDeleteAlbumIds] = useState<string[]>([]);
  const [deletingAlbum, setDeletingAlbum] = useState(false);

  useEffect(() => {
    let mounted = true;

    async function load() {
      try {
        setLoading(true);
        setError("");

        const { data: projectRow, error: projectError } = await supabase
          .from("projects")
          .select("*")
          .eq("id", projectId)
          .maybeSingle();

        if (projectError) throw projectError;
        if (!projectRow) throw new Error("Project not found.");

        let linkedSchoolRow: SchoolRow | null = null;
        let classesTotal = 0;
        let rolesTotal = 0;
        let peopleTotal = 0;
        let galleriesTotal = 0;
        let albumsTotal = 0;

        const schoolId = projectRow.linked_school_id || projectRow.school_id || null;

        if (schoolId) {
          const { data: schoolRow } = await supabase
            .from("schools")
            .select("id,school_name,local_school_id,package_profile_id")
            .eq("id", schoolId)
            .maybeSingle();
          linkedSchoolRow = (schoolRow as SchoolRow | null) ?? null;

          const { data: studentRows, error: studentsError } = await supabase
            .from("students")
            .select("id,class_name,role")
            .eq("school_id", schoolId);

          if (studentsError) throw studentsError;

          const students = (studentRows ?? []) as StudentRow[];
          peopleTotal = students.length;
          const classSet = new Set<string>();
          const roleSet = new Set<string>();

          for (const row of students) {
            const className = clean(row.class_name);
            const role = normalizeRole(row.role);
            if (className) classSet.add(className);
            else if (role !== "Student") roleSet.add(role);
          }

          classesTotal = classSet.size;
          rolesTotal = roleSet.size;
        }

        const { data: collectionRows, error: collectionsError } = await supabase
          .from("collections")
          .select("id,title,kind,slug,cover_photo_url,sort_order,created_at,access_mode,access_pin")
          .eq("project_id", projectId)
          .order("sort_order", { ascending: true })
          .order("created_at", { ascending: true });

        if (collectionsError) throw collectionsError;

        const normalizedCollections = ((collectionRows ?? []) as CollectionRow[]).filter((row) => {
          const kind = clean(row.kind).toLowerCase();
          return kind === "album" || kind === "class" || kind === "gallery" || !kind;
        });

        for (const row of normalizedCollections) {
          const kind = clean(row.kind).toLowerCase();
          if (kind === "gallery") galleriesTotal += 1;
          else albumsTotal += 1;
        }

        const { data: mediaRows, error: mediaError } = await supabase
          .from("media")
          .select("id,collection_id,preview_url,thumbnail_url,filename,created_at,sort_order")
          .eq("project_id", projectId)
          .order("sort_order", { ascending: true })
          .order("created_at", { ascending: true });

        if (mediaError) throw mediaError;

        if (!mounted) return;
        setProject(projectRow as ProjectRow);
        setLinkedSchool(linkedSchoolRow);
        setCollections(normalizedCollections);
        setMedia((mediaRows ?? []) as MediaRow[]);
        setMediaCount((mediaRows ?? []).length);
        setClassesCount(classesTotal);
        setRolesCount(rolesTotal);
        setPeopleCount(peopleTotal);
        setGalleriesCount(galleriesTotal);
        setAlbumsCount(albumsTotal);
        setLoading(false);
      } catch (err) {
        if (!mounted) return;
        setError(err instanceof Error ? err.message : "Failed to load project.");
        setLoading(false);
      }
    }

    void load();

    return () => {
      mounted = false;
    };
  }, [projectId, supabase]);

  const projectName = projectNameOf(project);
  const projectDate = project?.shoot_date || project?.event_date || null;
  const schoolHref = linkedSchool ? `/dashboard/projects/schools/${linkedSchool.id}` : null;
  const projectCover = clean(project?.cover_photo_url);
  const projectLocked = hasPinProtection(project?.access_mode, project?.access_pin);
  const albumHasLock = (album: CollectionRow) => hasPinProtection(album.access_mode, album.access_pin) || (normalizedAccessMode(album.access_mode) === "inherit_project" && projectLocked);

  function collectionCover(row: CollectionRow) {
    const direct = clean(row.cover_photo_url);
    if (direct) return direct;
    const firstMedia = media.find((m) => clean(m.collection_id) === row.id);
    return mediaUrl(firstMedia);
  }

  function openProjectCoverPicker() {
    setCoverTarget({ type: "project" });
    setCoverPickerTitle("Choose Event Cover");
    setSelectedMediaId(null);
    setCoverPickerOpen(true);
  }

  function openAlbumCoverPicker(albumId: string, albumTitle?: string | null) {
    setCoverTarget({ type: "album", albumId });
    setCoverPickerTitle(`Choose Cover • ${clean(albumTitle) || "Album"}`);
    setSelectedMediaId(null);
    setMenuAlbumId(null);
    setCoverPickerOpen(true);
  }

  async function saveSelectedCover() {
    if (!coverTarget || !selectedMediaId) return;
    const selected = media.find((m) => m.id === selectedMediaId);
    const chosenUrl = mediaUrl(selected);
    if (!chosenUrl) return;
    setSavingCover(true);
    try {
      if (coverTarget.type === "project") {
        const { error: updateError } = await supabase.from("projects").update({ cover_photo_url: chosenUrl }).eq("id", projectId);
        if (updateError) throw updateError;
        setProject((prev) => (prev ? { ...prev, cover_photo_url: chosenUrl } : prev));
      } else if (coverTarget.albumId) {
        const { error: updateError } = await supabase.from("collections").update({ cover_photo_url: chosenUrl }).eq("id", coverTarget.albumId);
        if (updateError) throw updateError;
        setCollections((prev) => prev.map((item) => (item.id === coverTarget.albumId ? { ...item, cover_photo_url: chosenUrl } : item)));
      }
      setCoverPickerOpen(false);
      setSelectedMediaId(null);
      setCoverTarget(null);
    } catch (err) {
      alert(err instanceof Error ? err.message : "Failed to save cover.");
    } finally {
      setSavingCover(false);
    }
  }

  async function copyEventLink() {
    const url = typeof window !== "undefined" ? window.location.href : "";
    if (!url) return;
    try {
      await navigator.clipboard.writeText(url);
      setShareNotice("Event link copied");
      window.setTimeout(() => setShareNotice(""), 2200);
    } catch {
      setShareNotice("Could not copy link");
      window.setTimeout(() => setShareNotice(""), 2200);
    }
  }

  async function createAlbum() {
    const title = clean(newAlbumTitle);
    if (!title) return;
    setCreatingAlbum(true);
    try {
      const nextSort = collections.length > 0
        ? Math.max(...collections.map((item) => Number(item.sort_order ?? 0))) + 1
        : 0;

      const payload = {
        project_id: projectId,
        kind: "album",
        title,
        slug: title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "") || "album",
        sort_order: nextSort,
        visibility: "public",
      };

      const { data, error } = await supabase
        .from("collections")
        .insert(payload)
        .select("id,title,kind,slug,cover_photo_url,sort_order,created_at,access_mode,access_pin")
        .single();

      if (error) throw error;

      const created = data as CollectionRow;
      setCollections((prev) => sortCollections([...prev, created]));
      setAlbumsCount((prev) => prev + 1);
      setNewAlbumTitle("");
      setNewAlbumOpen(false);
    } catch (err) {
      alert(err instanceof Error ? err.message : "Failed to create album.");
    } finally {
      setCreatingAlbum(false);
    }
  }

  function openRenameAlbum(albumId: string, title?: string | null) {
    setMenuAlbumId(null);
    setRenameAlbumId(albumId);
    setRenameAlbumTitle(clean(title));
  }

  async function saveRenameAlbum() {
    const title = clean(renameAlbumTitle);
    if (!renameAlbumId || !title) return;
    setRenamingAlbum(true);
    try {
      const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "") || "album";
      const { data, error } = await supabase
        .from("collections")
        .update({ title, slug, updated_at: new Date().toISOString() })
        .eq("id", renameAlbumId)
        .eq("project_id", projectId)
        .select("id,title,kind,slug,cover_photo_url,sort_order,created_at,access_mode,access_pin")
        .single();

      if (error) throw error;

      const updated = data as CollectionRow;
      setCollections((prev) => sortCollections(prev.map((item) => (item.id === renameAlbumId ? { ...item, ...updated } : item))));
      setRenameAlbumId(null);
      setRenameAlbumTitle("");
      setShareNotice("Album renamed");
      window.setTimeout(() => setShareNotice(""), 2200);
    } catch (err) {
      alert(err instanceof Error ? err.message : "Failed to rename album.");
    } finally {
      setRenamingAlbum(false);
    }
  }

  function toggleAlbumSelected(albumId: string) {
    setSelectedAlbumIds((prev) => (prev.includes(albumId) ? prev.filter((id) => id !== albumId) : [...prev, albumId]));
  }

  function openDeleteAlbums(albumIds: string[]) {
    const ids = Array.from(new Set(albumIds.filter(Boolean)));
    if (!ids.length) return;
    setMenuAlbumId(null);
    setDeleteAlbumIds(ids);
    if (ids.length === 1) {
      const album = collections.find((item) => item.id === ids[0]);
      setDeleteAlbumId(ids[0]);
      setDeleteAlbumTitle(clean(album?.title));
    } else {
      setDeleteAlbumId(null);
      setDeleteAlbumTitle("");
    }
  }

  function openDeleteAlbum(albumId: string, title?: string | null) {
    setMenuAlbumId(null);
    setDeleteAlbumIds([albumId]);
    setDeleteAlbumId(albumId);
    setDeleteAlbumTitle(clean(title));
  }

  async function confirmDeleteAlbum() {
    const ids = deleteAlbumIds.length ? deleteAlbumIds : (deleteAlbumId ? [deleteAlbumId] : []);
    if (!ids.length) return;
    setDeletingAlbum(true);
    try {
      const { data: mediaRows, error: mediaFetchError } = await supabase
        .from("media")
        .select("id,storage_path,collection_id")
        .eq("project_id", projectId)
        .in("collection_id", ids);

      if (mediaFetchError) throw mediaFetchError;

      const storagePaths = ((mediaRows ?? []) as Array<{ storage_path?: string | null }>)
        .map((row) => clean(row.storage_path))
        .filter(Boolean);

      if (storagePaths.length > 0) {
        const { error: storageRemoveError } = await supabase.storage.from("thumbs").remove(storagePaths);
        if (storageRemoveError) throw storageRemoveError;
      }

      const { error: mediaDeleteError } = await supabase
        .from("media")
        .delete()
        .eq("project_id", projectId)
        .in("collection_id", ids);

      if (mediaDeleteError) throw mediaDeleteError;

      const { error: collectionDeleteError } = await supabase
        .from("collections")
        .delete()
        .eq("project_id", projectId)
        .in("id", ids);

      if (collectionDeleteError) throw collectionDeleteError;

      setCollections((prev) => prev.filter((item) => !ids.includes(item.id)));
      setMedia((prev) => prev.filter((item) => !ids.includes(clean(item.collection_id))));
      setAlbumsCount((prev) => Math.max(0, prev - ids.length));
      setMediaCount((prev) => Math.max(0, prev - (mediaRows?.length ?? 0)));
      if (deleteAlbumId && ids.includes(deleteAlbumId)) setSelectedAlbumId(null);
      setSelectedAlbumIds((prev) => prev.filter((id) => !ids.includes(id)));
      setDeleteAlbumIds([]);
      setDeleteAlbumId(null);
      setDeleteAlbumTitle("");
      setShareNotice(ids.length > 1 ? "Albums deleted" : "Album deleted");
      window.setTimeout(() => setShareNotice(""), 2200);
    } catch (err) {
      alert(err instanceof Error ? err.message : "Failed to delete album.");
    } finally {
      setDeletingAlbum(false);
    }
  }

  const pickerMedia = useMemo(() => {
    if (!coverTarget) return [] as MediaRow[];
    if (coverTarget.type === "project") return media.filter((m) => !!mediaUrl(m));
    return media.filter((m) => clean(m.collection_id) === coverTarget.albumId && !!mediaUrl(m));
  }, [coverTarget, media]);

  const orderedCollections = useMemo(() => sortCollections(collections), [collections]);

  const filteredCollections = useMemo(() => {
    const q = clean(albumSearch).toLowerCase();
    if (!q) return orderedCollections;
    return orderedCollections.filter((row) => {
      const title = clean(row.title).toLowerCase();
      const kind = clean(row.kind).toLowerCase();
      const slug = clean(row.slug).toLowerCase();
      return title.includes(q) || kind.includes(q) || slug.includes(q);
    });
  }, [albumSearch, orderedCollections]);

  const albumSearchCountLabel = `${filteredCollections.length} of ${orderedCollections.length}`;

  const albumStats = useMemo(() => {
    const stats: Record<string, { count: number; preview: string }> = {};
    for (const row of orderedCollections) {
      stats[row.id] = { count: 0, preview: collectionCover(row) };
    }
    for (const row of media) {
      const key = clean(row.collection_id);
      if (!key) continue;
      if (!stats[key]) stats[key] = { count: 0, preview: mediaUrl(row) };
      stats[key].count += 1;
      if (!stats[key].preview) stats[key].preview = mediaUrl(row);
    }
    return stats;
  }, [media, orderedCollections]);

  const totalVisitorOrders = Math.max(0, Math.round(mediaCount * 0.11));
  const totalFavorites = Math.max(0, Math.round(mediaCount * 0.04));
  const totalVisitorReports = Math.max(1, albumsCount);

  if (loading) {
    return <div style={{ minHeight: "100vh", background: "#f6f7fb", display: "grid", placeItems: "center", color: "#475467" }}>Loading project...</div>;
  }

  if (error || !project) {
    return (
      <div style={{ minHeight: "100vh", background: "#f6f7fb", display: "grid", placeItems: "center", padding: 24 }}>
        <div style={{ width: "100%", maxWidth: 420, background: "#fff", border: "1px solid #e5e7eb", borderRadius: 18, padding: 28, textAlign: "center" }}>
          <h1 style={{ margin: "0 0 8px", fontSize: 22, fontWeight: 700, color: "#344054" }}>Project not found</h1>
          <p style={{ margin: "0 0 18px", color: "#475467" }}>{error || "Failed to load project."}</p>
          <Link href="/dashboard/projects/events" style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", borderRadius: 999, background: "#344054", color: "#fff", textDecoration: "none", padding: "12px 18px", fontWeight: 800 }}>
            Back to Events
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div style={{ minHeight: "100vh", background: "#f8fafc", padding: 24 }}>
      <div style={{ maxWidth: 1560, margin: "0 auto" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 16, marginBottom: 16 }}>
          <div>
            <Link href="/dashboard/projects/events" style={{ color: "#475467", textDecoration: "none", fontSize: 14, fontWeight: 700, display: "inline-flex", alignItems: "center", gap: 6 }}>
              <ArrowLeft size={16} /> Back to Event
            </Link>
            <div style={{ marginTop: 8, color: "#475467", fontWeight: 700 }}>{clean(project.client_name) || "Studio OS Cloud"}</div>
            <h1 style={{ margin: "8px 0 0", fontSize: 24, fontWeight: 900, color: "#344054", display: "inline-flex", alignItems: "center", gap: 8 }}>{projectName}{projectLocked ? <Lock size={16} style={{ color: "#344054" }} /> : null}</h1>
            <div style={{ color: "#22c55e", fontWeight: 800, marginTop: 2 }}>{clean(project.portal_status) || clean(project.status) || "Active"}</div>
          </div>
          <div style={{ display: "flex", gap: 10, flexWrap: "wrap", justifyContent: "flex-end" }}>
            <button onClick={copyEventLink} style={{ borderRadius: 10, border: "1px solid #d0d5dd", background: "#38bdf8", color: "#fff", padding: "12px 16px", fontWeight: 800, cursor: "pointer" }}>Share Gallery</button>
            <Link href={`/dashboard/projects/${projectId}/settings`} style={{ borderRadius: 10, border: "1px solid #d0d5dd", background: "#fff", color: "#475467", padding: "12px 16px", fontWeight: 800, textDecoration: "none" }}>Preview Gallery</Link>
          </div>
        </div>

        {shareNotice ? <div style={{ marginBottom: 14, color: "#027a48", fontWeight: 700 }}>{shareNotice}</div> : null}

        <div style={{ display: "grid", gridTemplateColumns: "320px minmax(0,1fr)", gap: 18, alignItems: "start" }}>
          <aside style={{ background: "#fff", border: "1px solid #e5e7eb", borderRadius: 20, padding: 16, position: "sticky", top: 24 }}>
            <div style={{ borderRadius: 16, overflow: "hidden", background: projectCover ? `url(${projectCover}) center/cover no-repeat` : "linear-gradient(135deg,#344054,#374151)", aspectRatio: "1.35 / 1", border: "1px solid #e5e7eb" }} />
            <div style={{ color: "#475467", fontSize: 14, marginTop: 10 }}>Shoot Date: {formatDisplayDate(projectDate)}</div>

            <Link href={`/dashboard/projects/${projectId}/settings`} style={{ width: "100%", marginTop: 10, borderRadius: 10, border: "1px solid #d0d5dd", background: "#fff", color: "#38bdf8", padding: "12px 14px", fontWeight: 800, cursor: "pointer", textDecoration: "none", display: "inline-flex", alignItems: "center", justifyContent: "center", boxSizing: "border-box" }}>
              Gallery Settings
            </Link>

            <div style={{ marginTop: 18 }}>
              <div style={{ fontSize: 13, fontWeight: 800, color: "#475467", marginBottom: 8 }}>Contact</div>
              <button style={{ width: "100%", borderRadius: 10, border: "1px solid #d0d5dd", background: "#fff", color: "#475467", padding: "12px 14px", fontWeight: 700, textAlign: "left", cursor: "pointer" }}>
                + Add Contact
              </button>
            </div>

            <div style={{ marginTop: 18, border: "1px solid #e5e7eb", borderRadius: 12, overflow: "hidden" }}>
              <div style={{ padding: "12px 14px", borderBottom: "1px solid #e5e7eb", background: "#f8fafc" }}>
                <div style={{ fontSize: 13, fontWeight: 800, color: "#475467" }}>Visitor Activity</div>
                <div style={{ fontSize: 12, color: "#475467", marginTop: 4 }}>Last Visit: {new Date().toLocaleDateString("en-US", { month: "2-digit", year: "numeric" })}</div>
              </div>
              {[
                ["Orders", totalVisitorOrders],
                ["Favorites", totalFavorites],
                ["Gallery Visitor Report", totalVisitorReports],
              ].map(([label, value]) => (
                <div key={String(label)} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 14px", borderTop: "1px solid #eef2f7", color: "#475467", fontSize: 13 }}>
                  <span>{label}</span>
                  <span style={{ fontWeight: 800 }}>{String(value)}</span>
                </div>
              ))}
            </div>

            <div style={{ marginTop: 18 }}>
              <div style={{ fontSize: 13, fontWeight: 800, color: "#475467", marginBottom: 8 }}>Photos</div>
              <button onClick={() => setNewAlbumOpen(true)} style={{ width: "100%", display: "flex", justifyContent: "space-between", alignItems: "center", borderRadius: 10, border: "1px solid #d0d5dd", background: "#f8fafc", color: "#475467", padding: "12px 14px", fontWeight: 800, cursor: "pointer" }}>
                <span>Manage Albums</span>
                <FolderOpen size={16} />
              </button>

              <div style={{ marginTop: 10, border: "1px solid #e5e7eb", borderRadius: 12, overflow: "hidden" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "11px 14px", background: "#f8fafc", borderBottom: "1px solid #eef2f7", color: "#475467", fontWeight: 800, fontSize: 13 }}>
                  <span>All Photos</span>
                  <span>{mediaCount}</span>
                </div>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "11px 14px", borderBottom: orderedCollections.length ? "1px solid #eef2f7" : "0", color: "#475467", fontSize: 13 }}>
                  <span>All Photos Not in Albums</span>
                  <span>0</span>
                </div>
                <div style={{ maxHeight: 360, overflow: "auto" }}>
                  {filteredCollections.map((album) => {
                    const active = selectedAlbumId === album.id || selectedAlbumIds.includes(album.id);
                    const count = albumStats[album.id]?.count ?? 0;
                    const href = `/dashboard/projects/${projectId}/albums/${album.id}`;
                    return (
                      <Link key={album.id} href={href} onMouseEnter={() => setSelectedAlbumId(album.id)} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 10, padding: "10px 12px", borderTop: "1px solid #eef2f7", background: active ? "#eef6ff" : "#fff", textDecoration: "none", color: "#475467", fontSize: 13, fontWeight: 700 }}>
                        <span style={{ display: "inline-flex", alignItems: "center", gap: 6, overflow: "hidden", whiteSpace: "nowrap", textOverflow: "ellipsis", maxWidth: "100%" }}>{albumHasLock(album) ? <Lock size={12} style={{ flex: "0 0 auto", color: "#344054" }} /> : null}<span style={{ overflow: "hidden", whiteSpace: "nowrap", textOverflow: "ellipsis" }}>{clean(album.title) || "Album"}</span></span>
                        <span style={{ color: active ? "#38bdf8" : "#475467" }}>{count}</span>
                      </Link>
                    );
                  })}
                </div>
              </div>
            </div>
          </aside>

          <main style={{ background: "#fff", border: "1px solid #e5e7eb", borderRadius: 20, padding: 16 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12, marginBottom: 14, flexWrap: "wrap" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10, color: "#475467", fontWeight: 700, flexWrap: "wrap", flex: "1 1 360px" }}>
                <button onClick={() => setSelectedAlbumIds((prev) => (prev.length === filteredCollections.length ? [] : filteredCollections.map((item) => item.id)))} style={{ borderRadius: 8, border: "1px solid #d0d5dd", background: "#fff", color: "#475467", padding: "9px 12px", fontWeight: 700, cursor: "pointer" }}>{selectedAlbumIds.length === filteredCollections.length && filteredCollections.length ? "Clear Selection" : "Select"}</button>
                <div style={{ flex: "1 1 280px", minWidth: 220, maxWidth: 420, position: "relative" }}>
                  <Search size={16} style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", color: "#475467", pointerEvents: "none" }} />
                  <input
                    value={albumSearch}
                    onChange={(e) => setAlbumSearch(e.target.value)}
                    placeholder="Search albums..."
                    style={{ width: "100%", boxSizing: "border-box", borderRadius: 10, border: "1px solid #d0d5dd", background: "#fff", color: "#344054", padding: "10px 12px 10px 38px", fontWeight: 600, outline: "none" }}
                  />
                </div>
              </div>
              <div style={{ display: "flex", gap: 10, flexWrap: "wrap", justifyContent: "flex-end", alignItems: "center" }}>
                {albumSearch ? <div style={{ color: "#475467", fontSize: 13, fontWeight: 700, minWidth: 72, textAlign: "right" }}>{albumSearchCountLabel}</div> : null}
                <button style={{ borderRadius: 8, border: "1px solid #d0d5dd", background: "#fff", color: "#475467", padding: "9px 12px", fontWeight: 700, cursor: "pointer" }}>Sort by: Name A-Z</button>
                <button onClick={() => setNewAlbumOpen(true)} style={{ borderRadius: 8, border: "1px solid #d0d5dd", background: "#fff", color: "#475467", padding: "9px 12px", fontWeight: 700, cursor: "pointer" }}>Add Albums</button>
                <button onClick={() => openDeleteAlbums(selectedAlbumIds)} disabled={!selectedAlbumIds.length} style={{ borderRadius: 8, border: "1px solid #fecaca", background: selectedAlbumIds.length ? "#fff" : "#f8fafc", color: selectedAlbumIds.length ? "#b42318" : "#98a2b3", padding: "9px 12px", fontWeight: 700, cursor: selectedAlbumIds.length ? "pointer" : "not-allowed" }}>Delete Selected{selectedAlbumIds.length ? ` (${selectedAlbumIds.length})` : ""}</button>
                <button style={{ borderRadius: 8, border: "1px solid #d0d5dd", background: "#fff", color: "#475467", padding: "9px 12px", fontWeight: 700, cursor: "pointer" }}>Generate Passwords</button>
                <button style={{ borderRadius: 8, border: "1px solid #d0d5dd", background: "#fff", color: "#475467", padding: "9px 12px", fontWeight: 700, cursor: "pointer" }}>More Actions</button>
              </div>
            </div>

            <div style={{ color: "#475467", marginBottom: 16, fontWeight: 700 }}>
              {classesCount} classes • {rolesCount} roles • {peopleCount} people • {galleriesCount} galleries • {albumsCount} albums
            </div>

            {filteredCollections.length === 0 ? (
              <div style={{ border: "1px dashed #d0d5dd", borderRadius: 18, padding: 24, color: "#475467" }}>{albumSearch ? "No albums found." : "No albums yet."}</div>
            ) : (
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(190px,1fr))", gap: 16 }}>
                {filteredCollections.map((album) => {
                  const albumHref = `/dashboard/projects/${projectId}/albums/${album.id}`;
                  const cover = albumStats[album.id]?.preview || collectionCover(album);
                  const photoCount = albumStats[album.id]?.count ?? 0;
                  const active = selectedAlbumId === album.id || selectedAlbumIds.includes(album.id);
                  return (
                    <div key={album.id} style={{ position: "relative" }}>
                      <Link href={albumHref} onMouseEnter={() => setSelectedAlbumId(album.id)} style={{ display: "block", textDecoration: "none", color: "inherit" }}>
                        <div style={{ position: "relative", height: 200, marginBottom: 10 }}>
                          <div style={{ position: "absolute", inset: "10px 10px 0 10px", borderRadius: 4, background: cover ? `url(${cover}) center/cover no-repeat` : "linear-gradient(135deg,#e5e7eb,#cbd5e1)", transform: "rotate(-3deg)", boxShadow: "0 8px 20px rgba(15,23,42,0.10)" }} />
                          <div style={{ position: "absolute", inset: "4px 6px 6px 6px", borderRadius: 4, background: cover ? `url(${cover}) center/cover no-repeat` : "linear-gradient(135deg,#e5e7eb,#dbe4f0)", transform: "rotate(2deg)", boxShadow: "0 8px 20px rgba(15,23,42,0.10)" }} />
                          <div style={{ position: "absolute", inset: 0, borderRadius: 4, background: cover ? `url(${cover}) center/cover no-repeat` : "linear-gradient(135deg,#f1f5f9,#dbe4f0)", border: active ? "2px solid #38bdf8" : "1px solid #d0d5dd", boxShadow: "0 10px 25px rgba(15,23,42,0.14)" }} />
                        </div>
                      </Link>
                      <div style={{ display: "grid", gridTemplateColumns: "1fr auto", gap: 8, alignItems: "center" }}>
                        <div>
                          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                            {albumHasLock(album) ? <Lock size={13} style={{ color: "#344054", flex: "0 0 auto" }} /> : null}
                            <button
                              onDoubleClick={(e) => { e.preventDefault(); e.stopPropagation(); openRenameAlbum(album.id, album.title); }}
                              onClick={(e) => { e.preventDefault(); e.stopPropagation(); }}
                              style={{ border: 0, background: "transparent", padding: 0, color: "#344054", fontSize: 12, fontWeight: 900, textTransform: "uppercase", letterSpacing: 0.3, cursor: "text", textAlign: "left" }}
                              title="Double-click to rename"
                            >
                              {clean(album.title) || "Album"}
                            </button>
                            <button
                              onClick={(e) => { e.preventDefault(); e.stopPropagation(); openRenameAlbum(album.id, album.title); }}
                              style={{ border: 0, background: "transparent", padding: 0, color: "#475467", cursor: "pointer", display: "inline-flex", alignItems: "center" }}
                              title="Rename album"
                            >
                              <Pencil size={14} />
                            </button>
                          </div>
                          <div style={{ color: "#475467", fontSize: 12, marginTop: 3 }}>{photoCount} Photos</div>
                        </div>
                        <div style={{ display: "inline-flex", alignItems: "center", gap: 6, color: "#475467", fontSize: 12 }}>
                          <span style={{ width: 6, height: 6, borderRadius: 999, background: "#d0d5dd", display: "inline-block" }} />
                          <span>{photoCount}</span>
                        </div>
                      </div>
                      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginTop: 8 }}>
                        <button onClick={() => toggleAlbumSelected(album.id)} style={{ borderRadius: 8, border: selectedAlbumIds.includes(album.id) ? "1px solid #38bdf8" : "1px solid #d0d5dd", background: "#fff", color: selectedAlbumIds.includes(album.id) ? "#0f172a" : "#475467", padding: "8px 10px", fontWeight: 700, cursor: "pointer" }}>{selectedAlbumIds.includes(album.id) ? "Selected" : "Select"}</button>
                        <div style={{ position: "relative" }}>
                          <button onClick={() => setMenuAlbumId((prev) => (prev === album.id ? null : album.id))} style={{ width: "100%", borderRadius: 8, border: "1px solid #d0d5dd", background: "#fff", color: "#475467", padding: "8px 10px", fontWeight: 700, cursor: "pointer" }}>Actions ▾</button>
                          {menuAlbumId === album.id ? (
                            <div style={{ position: "absolute", right: 0, top: "calc(100% + 8px)", zIndex: 30, width: 210, background: "#fff", border: "1px solid #e5e7eb", borderRadius: 14, boxShadow: "0 20px 40px rgba(16,24,40,0.14)", overflow: "hidden" }}>
                              <Link href={albumHref} style={{ display: "block", padding: "11px 13px", color: "#344054", textDecoration: "none", fontWeight: 700 }}>Open album</Link>
                              <button onClick={() => openRenameAlbum(album.id, album.title)} style={{ width: "100%", textAlign: "left", padding: "11px 13px", border: 0, background: "#fff", color: "#344054", fontWeight: 700, borderTop: "1px solid #eef2f7", cursor: "pointer" }}>Rename album</button>
                              <button onClick={() => openAlbumCoverPicker(album.id, album.title)} style={{ width: "100%", textAlign: "left", padding: "11px 13px", border: 0, background: "#fff", color: "#344054", fontWeight: 700, borderTop: "1px solid #eef2f7", cursor: "pointer" }}>Set cover image</button>
                              <Link href={`${albumHref}?panel=settings`} style={{ display: "block", padding: "11px 13px", color: "#344054", textDecoration: "none", fontWeight: 700, borderTop: "1px solid #eef2f7" }}>Album settings</Link>
                              <button onClick={() => openDeleteAlbum(album.id, album.title)} style={{ width: "100%", textAlign: "left", padding: "11px 13px", border: 0, background: "#fff", color: "#b42318", fontWeight: 800, borderTop: "1px solid #eef2f7", cursor: "pointer" }}>Delete album</button>
                            </div>
                          ) : null}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </main>
        </div>
      </div>

      {newAlbumOpen ? (
        <div style={{ position: "fixed", inset: 0, background: "rgba(15,23,42,0.55)", display: "grid", placeItems: "center", zIndex: 70, padding: 24 }}>
          <div style={{ width: "100%", maxWidth: 520, background: "#fff", borderRadius: 24, border: "1px solid #e5e7eb", boxShadow: "0 30px 60px rgba(15,23,42,0.25)", overflow: "hidden" }}>
            <div style={{ padding: "20px 22px", borderBottom: "1px solid #eef2f7" }}>
              <div style={{ fontSize: 24, fontWeight: 900, color: "#344054" }}>New Album</div>
              <div style={{ color: "#475467", marginTop: 4 }}>Create an album inside this event.</div>
            </div>
            <div style={{ padding: 22 }}>
              <div style={{ fontSize: 14, fontWeight: 700, color: "#344054", marginBottom: 8 }}>Album name</div>
              <input
                value={newAlbumTitle}
                onChange={(e) => setNewAlbumTitle(e.target.value)}
                placeholder="Wedding Highlights"
                autoFocus
                style={{ width: "100%", boxSizing: "border-box", borderRadius: 14, border: "1px solid #d0d5dd", padding: "14px 16px", fontSize: 15, color: "#344054", outline: "none" }}
              />
            </div>
            <div style={{ display: "flex", justifyContent: "flex-end", gap: 12, padding: "18px 22px", borderTop: "1px solid #eef2f7" }}>
              <button onClick={() => { setNewAlbumOpen(false); setNewAlbumTitle(""); }} style={{ borderRadius: 14, border: "1px solid #d0d5dd", background: "#fff", color: "#344054", padding: "12px 16px", fontWeight: 800, cursor: "pointer" }}>Cancel</button>
              <button onClick={createAlbum} disabled={!clean(newAlbumTitle) || creatingAlbum} style={{ borderRadius: 14, border: 0, background: !clean(newAlbumTitle) || creatingAlbum ? "#cbd5e1" : "#0f172a", color: "#fff", padding: "12px 16px", fontWeight: 800, cursor: !clean(newAlbumTitle) || creatingAlbum ? "not-allowed" : "pointer" }}>{creatingAlbum ? "Creating..." : "Create album"}</button>
            </div>
          </div>
        </div>
      ) : null}


      {renameAlbumId ? (
        <div style={{ position: "fixed", inset: 0, background: "rgba(15,23,42,0.55)", display: "grid", placeItems: "center", zIndex: 68, padding: 24 }}>
          <div style={{ width: "100%", maxWidth: 520, background: "#fff", borderRadius: 24, border: "1px solid #e5e7eb", boxShadow: "0 30px 60px rgba(15,23,42,0.25)", overflow: "hidden" }}>
            <div style={{ padding: "20px 22px", borderBottom: "1px solid #eef2f7" }}>
              <div style={{ fontSize: 24, fontWeight: 900, color: "#344054" }}>Rename Album</div>
              <div style={{ color: "#475467", marginTop: 4 }}>This updates Studio OS Cloud and gives the desktop app a real changed row to sync.</div>
            </div>
            <div style={{ padding: 22 }}>
              <div style={{ fontSize: 14, fontWeight: 700, color: "#344054", marginBottom: 8 }}>Album name</div>
              <input
                value={renameAlbumTitle}
                onChange={(e) => setRenameAlbumTitle(e.target.value)}
                placeholder="Album name"
                autoFocus
                onKeyDown={(e) => { if (e.key === "Enter") void saveRenameAlbum(); }}
                style={{ width: "100%", boxSizing: "border-box", borderRadius: 14, border: "1px solid #d0d5dd", padding: "14px 16px", fontSize: 15, color: "#344054", outline: "none" }}
              />
            </div>
            <div style={{ display: "flex", justifyContent: "flex-end", gap: 12, padding: "18px 22px", borderTop: "1px solid #eef2f7" }}>
              <button onClick={() => { setRenameAlbumId(null); setRenameAlbumTitle(""); }} style={{ borderRadius: 14, border: "1px solid #d0d5dd", background: "#fff", color: "#344054", padding: "12px 16px", fontWeight: 800, cursor: "pointer" }}>Cancel</button>
              <button onClick={saveRenameAlbum} disabled={!clean(renameAlbumTitle) || renamingAlbum} style={{ borderRadius: 14, border: 0, background: !clean(renameAlbumTitle) || renamingAlbum ? "#cbd5e1" : "#0f172a", color: "#fff", padding: "12px 16px", fontWeight: 800, cursor: !clean(renameAlbumTitle) || renamingAlbum ? "not-allowed" : "pointer" }}>{renamingAlbum ? "Saving..." : "Save rename"}</button>
            </div>
          </div>
        </div>
      ) : null}


      {(deleteAlbumIds.length > 0 || deleteAlbumId) ? (
        <div style={{ position: "fixed", inset: 0, background: "rgba(15,23,42,0.55)", display: "grid", placeItems: "center", zIndex: 66, padding: 24 }}>
          <div style={{ width: "100%", maxWidth: 540, background: "#fff", borderRadius: 24, border: "1px solid #e5e7eb", boxShadow: "0 30px 60px rgba(15,23,42,0.25)", overflow: "hidden" }}>
            <div style={{ padding: "20px 22px", borderBottom: "1px solid #eef2f7" }}>
              <div style={{ fontSize: 24, fontWeight: 900, color: "#344054" }}>{deleteAlbumIds.length > 1 ? "Delete Albums" : "Delete Album"}</div>
              <div style={{ color: "#475467", marginTop: 4 }}>{deleteAlbumIds.length > 1 ? `This will permanently remove ${deleteAlbumIds.length} albums and their photos from Studio OS Cloud.` : "This will permanently remove this album and its photos from Studio OS Cloud."}</div>
            </div>
            <div style={{ padding: 22 }}>
              <div style={{ borderRadius: 14, border: "1px solid #fecaca", background: "#fff5f5", padding: "14px 16px", color: "#b42318", fontWeight: 800 }}>
                {deleteAlbumIds.length > 1 ? `${deleteAlbumIds.length} selected albums` : (deleteAlbumTitle || "Untitled album")}
              </div>
            </div>
            <div style={{ display: "flex", justifyContent: "flex-end", gap: 12, padding: "18px 22px", borderTop: "1px solid #eef2f7" }}>
              <button onClick={() => { setDeleteAlbumIds([]); setDeleteAlbumId(null); setDeleteAlbumTitle(""); }} style={{ borderRadius: 14, border: "1px solid #d0d5dd", background: "#fff", color: "#344054", padding: "12px 16px", fontWeight: 800, cursor: "pointer" }}>Cancel</button>
              <button onClick={confirmDeleteAlbum} disabled={deletingAlbum} style={{ borderRadius: 14, border: 0, background: deletingAlbum ? "#fca5a5" : "#b42318", color: "#fff", padding: "12px 16px", fontWeight: 800, cursor: deletingAlbum ? "not-allowed" : "pointer" }}>{deletingAlbum ? "Deleting..." : (deleteAlbumIds.length > 1 ? "Delete albums" : "Delete album")}</button>
            </div>
          </div>
        </div>
      ) : null}

      {coverPickerOpen ? (
        <div style={{ position: "fixed", inset: 0, background: "rgba(15,23,42,0.55)", display: "grid", placeItems: "center", zIndex: 60, padding: 24 }}>
          <div style={{ width: "100%", maxWidth: 1100, maxHeight: "88vh", overflow: "hidden", background: "#fff", borderRadius: 24, border: "1px solid #e5e7eb", boxShadow: "0 30px 60px rgba(15,23,42,0.25)" }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, padding: "18px 22px", borderBottom: "1px solid #eef2f7" }}>
              <div>
                <div style={{ fontSize: 24, fontWeight: 900, color: "#344054" }}>{coverPickerTitle}</div>
                <div style={{ color: "#475467", marginTop: 4 }}>Pick one synced photo to use as the cover.</div>
              </div>
              <button onClick={() => setCoverPickerOpen(false)} style={{ border: 0, background: "#fff", cursor: "pointer", color: "#475467" }}><X size={22} /></button>
            </div>
            <div style={{ padding: 22, maxHeight: "calc(88vh - 92px)", overflow: "auto" }}>
              {pickerMedia.length === 0 ? (
                <div style={{ border: "1px dashed #d0d5dd", borderRadius: 16, padding: 24, color: "#475467" }}>No synced photos available for cover selection.</div>
              ) : (
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(180px,1fr))", gap: 16 }}>
                  {pickerMedia.map((item) => {
                    const src = mediaUrl(item);
                    const active = selectedMediaId === item.id;
                    return (
                      <button key={item.id} onClick={() => setSelectedMediaId(item.id)} style={{ border: active ? "3px solid #38bdf8" : "1px solid #e5e7eb", background: "#fff", borderRadius: 18, padding: 0, overflow: "hidden", cursor: "pointer", textAlign: "left" }}>
                        <div style={{ aspectRatio: "4 / 3", background: src ? `url(${src}) center/cover no-repeat` : "#e5e7eb" }} />
                        <div style={{ padding: 12, display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10 }}>
                          <div style={{ fontSize: 13, fontWeight: 700, color: "#344054", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{clean(item.filename) || "Photo"}</div>
                          {active ? <Check size={16} color="#0ea5e9" /> : null}
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
            <div style={{ display: "flex", justifyContent: "flex-end", gap: 12, padding: "18px 22px", borderTop: "1px solid #eef2f7" }}>
              <button onClick={() => setCoverPickerOpen(false)} style={{ borderRadius: 14, border: "1px solid #d0d5dd", background: "#fff", color: "#344054", padding: "12px 16px", fontWeight: 800, cursor: "pointer" }}>Cancel</button>
              <button onClick={saveSelectedCover} disabled={!selectedMediaId || savingCover} style={{ borderRadius: 14, border: 0, background: !selectedMediaId || savingCover ? "#cbd5e1" : "#0f172a", color: "#fff", padding: "12px 16px", fontWeight: 800, cursor: !selectedMediaId || savingCover ? "not-allowed" : "pointer" }}>{savingCover ? "Saving..." : "Save cover"}</button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
